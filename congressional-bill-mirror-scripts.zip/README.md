# BillReader

An automated pipeline that fetches US federal bills that have cleared committee,
simplifies them to approximately a sixth-grade reading level using AI, and
publishes them to a static site with a built-in text-to-speech reader.

## How it works

1. A scheduled GitHub Action runs twice daily
2. It polls the Congress.gov API for bills that have advanced past committee
3. New or updated bills are processed through the Anthropic API in chunks
4. Output is stored as structured JSON (one object per section) in /data/bills/
5. Cloudflare Pages serves the static site from /site/

## Repo structure

```
/
├── .github/
│   └── workflows/
│       └── fetch_and_process.yml   # Scheduled pipeline
├── scripts/
│   ├── fetch_bills.py              # Polls Congress.gov API
│   ├── process_bill.py             # Sends bill text to Anthropic API
│   ├── build_index.py              # Rebuilds the bill index JSON
│   └── utils.py                   # Shared helpers (hashing, chunking, etc.)
├── data/
│   └── bills/
│       └── {congress}-{bill-id}/
│           ├── meta.json           # Bill metadata, stage, version hash
│           ├── original.txt        # Raw bill text from Congress.gov
│           └── simplified.json     # Structured simplified output (sections)
├── site/
│   ├── public/
│   │   └── index.json             # Master bill index for the frontend
│   └── src/
│       └── index.html             # Static reader site
└── README.md
```

## Data schema

Each simplified.json file looks like this:

```json
{
  "bill_id": "119-s-1247",
  "title": "BITCOIN Act of 2025",
  "short_title": "BITCOIN Act of 2025",
  "congress": 119,
  "bill_number": "S.1247",
  "introduced_date": "2025-03-11",
  "stage": "reported_by_committee",
  "stage_label": "Passed Committee",
  "version_hash": "abc123...",
  "last_updated": "2025-03-15T12:00:00Z",
  "plain_summary": "A short 2-3 sentence plain language summary of the whole bill.",
  "sections": [
    {
      "id": "s1",
      "slug": "short-title",
      "title": "Section 1  Short Title",
      "word_offset": 0,
      "char_offset": 0,
      "text": "Simplified section text goes here..."
    }
  ]
}
```

The word_offset and char_offset fields on each section are what enable
section-level deep linking and timestamped TTS sharing in a future update.
They are populated at processing time so no reprocessing is needed later.

## Setup

### Required secrets (set in GitHub repo settings)

- CONGRESS_API_KEY   -- Free from api.congress.gov
- ANTHROPIC_API_KEY  -- From console.anthropic.com

### Local development

```bash
pip install -r requirements.txt
python scripts/fetch_bills.py --dry-run
```

## Cost estimate

Processing a typical 50-100 page bill costs roughly $0.10 to $0.50 in API fees.
The longest bill ever passed (5,593 pages) would cost roughly $15 to $25.
Monthly spend for bills clearing committee during an active session is
estimated at $10 to $30.

## Future features (no data changes needed)

- Table of contents with section jump links
- Section-level share button generating a deep link with word offset
- TTS playback with timestamp so shared links resume at correct position
- Bill stage timeline / progress tracker
- Diff view showing what changed between bill versions
