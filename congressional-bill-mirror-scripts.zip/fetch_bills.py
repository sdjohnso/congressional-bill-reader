"""
fetch_bills.py
Polls the Congress.gov API for bills that have cleared committee and
queues them for processing if they are new or have been updated.

Usage:
    python scripts/fetch_bills.py           # Normal run
    python scripts/fetch_bills.py --dry-run # Print what would be queued, no writes
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, str(Path(__file__).parent))
from utils import hash_text, bill_folder_name

API_KEY = os.environ.get("CONGRESS_API_KEY", "")
BASE_URL = "https://api.congress.gov/v3"
DATA_DIR = Path(__file__).parent.parent / "data" / "bills"

# Bill stages that indicate the bill has cleared committee.
# Congress.gov action codes reference:
# https://www.congress.gov/help/legislative-glossary
COMMITTEE_CLEARED_ACTIONS = [
    "Reported by",
    "Ordered to be Reported",
    "Reported (Amended)",
    "Committee on",  # catch-all for committee action lines
]

# How many bills to fetch per API page (max 250)
PAGE_SIZE = 50

# Which Congress to track (update each new Congress)
TARGET_CONGRESS = 119


def fetch_json(url: str, params: dict) -> dict:
    """Make a GET request to the Congress.gov API with rate-limit handling."""
    params["api_key"] = API_KEY
    params["format"] = "json"
    for attempt in range(3):
        try:
            resp = requests.get(url, params=params, timeout=30)
            if resp.status_code == 429:
                print("Rate limited. Waiting 10 seconds...")
                time.sleep(10)
                continue
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            if attempt == 2:
                raise
            print(f"Request failed ({e}), retrying...")
            time.sleep(3)
    return {}


def get_bills_past_committee(congress: int, offset: int = 0) -> list[dict]:
    """
    Fetch a page of bills from the given Congress that have had committee action.
    Returns list of bill summary dicts from the API.
    """
    url = f"{BASE_URL}/bill/{congress}"
    params = {
        "limit": PAGE_SIZE,
        "offset": offset,
        "sort": "updateDate+desc",
    }
    data = fetch_json(url, params)
    return data.get("bills", [])


def get_bill_actions(congress: int, bill_type: str, bill_number: str) -> list[dict]:
    """Fetch the action history for a specific bill."""
    url = f"{BASE_URL}/bill/{congress}/{bill_type.lower()}/{bill_number}/actions"
    data = fetch_json(url, {"limit": 50})
    return data.get("actions", [])


def get_bill_text_url(congress: int, bill_type: str, bill_number: str) -> str | None:
    """
    Fetch the text versions for a bill and return the URL of the most recent
    plain-text version. Prefers TXT, falls back to XML.
    """
    url = f"{BASE_URL}/bill/{congress}/{bill_type.lower()}/{bill_number}/text"
    data = fetch_json(url, {"limit": 10})
    versions = data.get("textVersions", [])
    if not versions:
        return None
    # Take the most recent version
    latest = versions[0]
    formats = latest.get("formats", [])
    # Prefer plain text
    for fmt in formats:
        if fmt.get("type", "").upper() == "Formatted Text":
            return fmt.get("url")
    # Fall back to XML
    for fmt in formats:
        if fmt.get("type", "").upper() in ("XML", "Formatted XML"):
            return fmt.get("url")
    return None


def fetch_bill_text(text_url: str) -> str:
    """Download the raw text of a bill from the given URL."""
    resp = requests.get(text_url, timeout=60)
    resp.raise_for_status()
    # Strip HTML tags if the response is HTML/XML
    text = resp.text
    if text.strip().startswith("<"):
        import re
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
    return text


def bill_has_cleared_committee(actions: list[dict]) -> tuple[bool, str]:
    """
    Check whether any action in the bill's history indicates committee clearance.
    Returns (cleared: bool, stage_label: str).
    """
    for action in actions:
        text = action.get("text", "")
        for keyword in COMMITTEE_CLEARED_ACTIONS:
            if keyword.lower() in text.lower():
                return True, text[:120]
    return False, ""


def load_existing_meta(folder: Path) -> dict:
    """Load existing meta.json for a bill, or return empty dict."""
    meta_path = folder / "meta.json"
    if meta_path.exists():
        with open(meta_path) as f:
            return json.load(f)
    return {}


def save_meta(folder: Path, meta: dict):
    """Write meta.json for a bill."""
    folder.mkdir(parents=True, exist_ok=True)
    with open(folder / "meta.json", "w") as f:
        json.dump(meta, f, indent=2)


def queue_bill_for_processing(folder: Path):
    """Write a needs_processing flag file so the process_bill script picks it up."""
    (folder / "needs_processing").touch()


def run(dry_run: bool = False):
    if not API_KEY:
        print("ERROR: CONGRESS_API_KEY environment variable not set.")
        sys.exit(1)

    print(f"Fetching bills for Congress {TARGET_CONGRESS}...")
    queued = 0
    skipped = 0
    offset = 0
    max_pages = 20  # Safety cap; increase if needed

    for page in range(max_pages):
        bills = get_bills_past_committee(TARGET_CONGRESS, offset)
        if not bills:
            break

        for bill in bills:
            congress = bill.get("congress")
            bill_type = bill.get("type", "").lower()
            number = str(bill.get("number", ""))
            title = bill.get("title", "Untitled")
            update_date = bill.get("updateDate", "")

            folder_name = bill_folder_name(congress, bill_type, number)
            folder = DATA_DIR / folder_name
            existing_meta = load_existing_meta(folder)

            # Skip if we already have this exact version
            if existing_meta.get("update_date") == update_date and existing_meta.get("simplified_complete"):
                skipped += 1
                continue

            # Check if this bill has actually cleared committee
            print(f"  Checking actions for {bill_type.upper()}.{number}: {title[:60]}")
            actions = get_bill_actions(congress, bill_type, number)
            cleared, stage_label = bill_has_cleared_committee(actions)

            if not cleared:
                skipped += 1
                continue

            # Get the text URL
            text_url = get_bill_text_url(congress, bill_type, number)
            if not text_url:
                print(f"    No text available yet for {bill_type.upper()}.{number}, skipping.")
                skipped += 1
                continue

            print(f"  QUEUED: {bill_type.upper()}.{number} - {title[:60]}")
            print(f"    Stage: {stage_label[:80]}")

            if not dry_run:
                folder.mkdir(parents=True, exist_ok=True)
                meta = {
                    "bill_id": folder_name,
                    "congress": congress,
                    "bill_type": bill_type,
                    "bill_number": number,
                    "title": title,
                    "update_date": update_date,
                    "stage_label": stage_label,
                    "text_url": text_url,
                    "simplified_complete": False,
                    "queued_at": datetime.now(timezone.utc).isoformat(),
                }
                save_meta(folder, meta)
                queue_bill_for_processing(folder)

            queued += 1
            time.sleep(0.5)  # Be polite to the API

        offset += PAGE_SIZE
        if len(bills) < PAGE_SIZE:
            break
        time.sleep(1)

    print(f"\nDone. Queued: {queued}  Skipped (unchanged or no text): {skipped}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="Print what would be queued without writing files")
    args = parser.parse_args()
    run(dry_run=args.dry_run)
